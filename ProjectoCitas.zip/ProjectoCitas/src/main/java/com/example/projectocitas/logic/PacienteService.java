package com.example.projectocitas.logic;

import com.example.projectocitas.Perfile;
import com.example.projectocitas.data.PacienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PacienteService {

}
