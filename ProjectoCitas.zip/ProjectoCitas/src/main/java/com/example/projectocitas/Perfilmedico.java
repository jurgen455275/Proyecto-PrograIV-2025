package com.example.projectocitas;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

@Entity
@Table(name = "perfilmedico")
public class Perfilmedico {
    @Id
    @Size(max = 10)
    @Column(name = "id_cedula", nullable = false, length = 10)
    private String idCedula;

    @MapsId
    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_cedula", nullable = false)
    private com.example.projectocitas.Usuario usuario;

    @Size(max = 50)
    @Column(name = "especialidad", length = 50)
    private String especialidad;

    @Column(name = "costo_consulta", precision = 10, scale = 2)
    private BigDecimal costoConsulta;

    @Size(max = 50)
    @Column(name = "localidad", length = 50)
    private String localidad;

    @Size(max = 500)
    @Column(name = "horario_semanal", length = 500)
    private String horarioSemanal;

    @Column(name = "frecuencia")
    private Integer frecuencia;

    public String getIdCedula() {
        return idCedula;
    }

    public void setIdCedula(String idCedula) {
        this.idCedula = idCedula;
    }

    public com.example.projectocitas.Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(com.example.projectocitas.Usuario usuario) {
        this.usuario = usuario;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public BigDecimal getCostoConsulta() {
        return costoConsulta;
    }

    public void setCostoConsulta(BigDecimal costoConsulta) {
        this.costoConsulta = costoConsulta;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public String getHorarioSemanal() {
        return horarioSemanal;
    }

    public void setHorarioSemanal(String horarioSemanal) {
        this.horarioSemanal = horarioSemanal;
    }

    public Integer getFrecuencia() {
        return frecuencia;
    }

    public void setFrecuencia(Integer frecuencia) {
        this.frecuencia = frecuencia;
    }

}