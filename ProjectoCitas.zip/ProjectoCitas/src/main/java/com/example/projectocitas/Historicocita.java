package com.example.projectocitas;

import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "historicocitas")
public class Historicocita {
    @Id
    @Column(name = "historico_id", nullable = false)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_cita")
    private Cita idCita;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_paciente")
    private com.example.projectocitas.Usuario idPaciente;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_medico")
    private com.example.projectocitas.Usuario idMedico;

    @Column(name = "fecha")
    private Instant fecha;

    @Lob
    @Column(name = "estado")
    private String estado;

    @Lob
    @Column(name = "anotaciones")
    private String anotaciones;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Cita getIdCita() {
        return idCita;
    }

    public void setIdCita(Cita idCita) {
        this.idCita = idCita;
    }

    public com.example.projectocitas.Usuario getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(com.example.projectocitas.Usuario idPaciente) {
        this.idPaciente = idPaciente;
    }

    public com.example.projectocitas.Usuario getIdMedico() {
        return idMedico;
    }

    public void setIdMedico(com.example.projectocitas.Usuario idMedico) {
        this.idMedico = idMedico;
    }

    public Instant getFecha() {
        return fecha;
    }

    public void setFecha(Instant fecha) {
        this.fecha = fecha;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getAnotaciones() {
        return anotaciones;
    }

    public void setAnotaciones(String anotaciones) {
        this.anotaciones = anotaciones;
    }

}