package com.example.projectocitas.data;

import com.example.projectocitas.Perfile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PacienteRepository extends JpaRepository<Perfile, Long> {
}
