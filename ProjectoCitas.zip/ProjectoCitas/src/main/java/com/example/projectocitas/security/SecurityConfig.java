package com.example.projectocitas.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(customizer -> customizer
                        .requestMatchers("admin/**").hasRole("ADMIN")
                        .requestMatchers("medicos/**").hasRole("MEDICO")
                        .requestMatchers("pacientes/**").hasRole("PACIENTE")
                        .anyRequest().permitAll()
                ).formLogin(customizer -> customizer
                        .loginPage("/login")
                        .permitAll()
                ).logout(customizer -> customizer
                        .permitAll()
                        .logoutSuccessUrl("/")
                ).exceptionHandling(customizer -> customizer
                        .accessDeniedPage("/notAuthorized")
                ).csrf(customizer -> customizer.disable());
        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
