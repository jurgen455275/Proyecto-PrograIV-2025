package com.example.projectocitas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectoCitasApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjectoCitasApplication.class, args);
    }

}
