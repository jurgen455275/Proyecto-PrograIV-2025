package com.example.projectocitas;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;

import java.time.LocalTime;

@Entity
@Table(name = "horario")
public class Horario {
    @Id
    @Column(name = "horario_id", nullable = false)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_medico")
    private com.example.projectocitas.Usuario idMedico;

    @Size(max = 10)
    @Column(name = "dia", length = 10)
    private String dia;

    @Column(name = "hora_inicio")
    private LocalTime horaInicio;

    @Column(name = "hora_fin")
    private LocalTime horaFin;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public com.example.projectocitas.Usuario getIdMedico() {
        return idMedico;
    }

    public void setIdMedico(com.example.projectocitas.Usuario idMedico) {
        this.idMedico = idMedico;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public LocalTime getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(LocalTime horaInicio) {
        this.horaInicio = horaInicio;
    }

    public LocalTime getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(LocalTime horaFin) {
        this.horaFin = horaFin;
    }

}