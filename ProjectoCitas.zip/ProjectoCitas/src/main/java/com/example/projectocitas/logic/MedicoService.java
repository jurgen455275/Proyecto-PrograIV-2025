package com.example.projectocitas.logic;

import com.example.projectocitas.Medico;
import com.example.projectocitas.data.MedicoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MedicoService {

}
