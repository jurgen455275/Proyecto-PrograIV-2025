package com.example.projectocitas.logic;

import com.example.projectocitas.Usuario;
import com.example.projectocitas.data.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class UsuarioService {

}
