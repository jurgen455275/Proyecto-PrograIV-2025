package com.example.projectocitas;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "perfiles")
public class Perfile {
    @Id
    @Column(name = "perfil_id", nullable = false)
    private Integer id;

    @Size(max = 50)
    @Column(name = "perfil_nombre", length = 50)
    private String perfilNombre;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPerfilNombre() {
        return perfilNombre;
    }

    public void setPerfilNombre(String perfilNombre) {
        this.perfilNombre = perfilNombre;
    }

}