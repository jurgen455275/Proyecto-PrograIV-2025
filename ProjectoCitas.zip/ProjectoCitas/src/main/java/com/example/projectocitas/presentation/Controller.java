package com.example.projectocitas.presentation;

import org.springframework.web.bind.annotation.GetMapping;

@org.springframework.stereotype.Controller
public class Controller {
    @GetMapping("/")
    public String home() {
        return "pacientes/BuscarCitaView";
    }

    @GetMapping("/login")
    public String login() {
        return "login/login";
    }
}