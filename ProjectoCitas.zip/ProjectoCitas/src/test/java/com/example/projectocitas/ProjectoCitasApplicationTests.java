package com.example.projectocitas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectoCitasApplicationTests {

    @Test
    void contextLoads() {
    }

}
